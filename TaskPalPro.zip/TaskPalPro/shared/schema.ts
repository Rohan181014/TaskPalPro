import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  created_at: text("created_at").default("CURRENT_TIMESTAMP").notNull(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  parent_id: integer("parent_id").references(() => tasks.id),
  title: text("title").notNull(),
  description: text("description"),
  due_date: text("due_date"),
  weight: integer("weight").default(3),
  position: integer("position").default(0),
  completed: boolean("completed").default(false),
  created_at: text("created_at").default("CURRENT_TIMESTAMP").notNull(),
  updated_at: text("updated_at").default("CURRENT_TIMESTAMP").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
});

export const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  user_id: true,
  parent_id: true,
  title: true,
  description: true,
  due_date: true,
  weight: true,
  position: true,
});

export const updateTaskSchema = createInsertSchema(tasks).pick({
  parent_id: true,
  title: true,
  description: true,
  due_date: true,
  weight: true,
  position: true,
  completed: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type UpdateTask = z.infer<typeof updateTaskSchema>;
export type Task = typeof tasks.$inferSelect;
