import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, loginUserSchema, insertTaskSchema, updateTaskSchema
} from "@shared/schema";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

// Session setup
const MemorySessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Configure session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "taskpal-secret-key",
      resave: false,
      saveUninitialized: false,
      store: new MemorySessionStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      cookie: {
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      }
    })
  );
  
  // Set up Passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.validateUser(username, password);
      if (!user) {
        return done(null, false, { message: "Invalid username or password" });
      }
      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }));
  
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });
  
  // Authentication middleware
  const ensureAuth = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };
  
  // Register route
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUserByUsername = await storage.getUserByUsername(userData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Check if email already exists
      const existingUserByEmail = await storage.getUserByEmail(userData.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json({
        id: user.id,
        username: user.username,
        email: user.email
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "An error occurred during registration" });
    }
  });
  
  // Login route
  app.post("/api/login", (req, res, next) => {
    try {
      loginUserSchema.parse(req.body);
      passport.authenticate("local", (err: any, user: any, info: any) => {
        if (err) {
          return next(err);
        }
        if (!user) {
          return res.status(401).json({ message: info.message || "Authentication failed" });
        }
        req.logIn(user, (loginErr) => {
          if (loginErr) {
            return next(loginErr);
          }
          return res.status(200).json({
            id: user.id,
            username: user.username,
            email: user.email
          });
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "An error occurred during login" });
    }
  });
  
  // Logout route
  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error during logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });
  
  // Get current user
  app.get("/api/user", ensureAuth, (req, res) => {
    const user = req.user as any;
    res.json({
      id: user.id,
      username: user.username,
      email: user.email
    });
  });
  
  // Get all tasks for the current user
  app.get("/api/tasks", ensureAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const tasks = await storage.getAllTasks(user.id);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tasks" });
    }
  });
  
  // Create a new task
  app.post("/api/tasks", ensureAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const taskData = insertTaskSchema.parse({
        ...req.body,
        user_id: user.id
      });
      
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Error creating task" });
    }
  });
  
  // Update a task
  app.put("/api/tasks/:id", ensureAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const taskId = parseInt(req.params.id);
      
      // Check if task exists and belongs to the user
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (existingTask.user_id !== user.id) {
        return res.status(403).json({ message: "You don't have permission to update this task" });
      }
      
      const taskData = updateTaskSchema.parse(req.body);
      const updatedTask = await storage.updateTask(taskId, taskData);
      res.json(updatedTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Error updating task" });
    }
  });
  
  // Delete a task
  app.delete("/api/tasks/:id", ensureAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const taskId = parseInt(req.params.id);
      
      // Check if task exists and belongs to the user
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (existingTask.user_id !== user.id) {
        return res.status(403).json({ message: "You don't have permission to delete this task" });
      }
      
      const success = await storage.deleteTask(taskId);
      
      if (success) {
        res.status(200).json({ message: "Task deleted successfully" });
      } else {
        res.status(500).json({ message: "Error deleting task" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error deleting task" });
    }
  });
  
  // Get task children
  app.get("/api/tasks/:id/children", ensureAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const taskId = parseInt(req.params.id);
      
      // Check if task exists and belongs to the user
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (existingTask.user_id !== user.id) {
        return res.status(403).json({ message: "You don't have permission to view this task" });
      }
      
      const children = await storage.getTaskChildren(taskId);
      res.json(children);
    } catch (error) {
      res.status(500).json({ message: "Error fetching child tasks" });
    }
  });
  
  // Reorder a task (update position and/or parent)
  app.put("/api/tasks/:id/reorder", ensureAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const taskId = parseInt(req.params.id);
      
      // Check if task exists and belongs to the user
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (existingTask.user_id !== user.id) {
        return res.status(403).json({ message: "You don't have permission to reorder this task" });
      }
      
      // Validate the request body
      const reorderSchema = z.object({
        parent_id: z.number().nullable(),
        position: z.number().min(0)
      });
      
      const reorderData = reorderSchema.parse(req.body);
      
      // Update the task with new parent_id and position
      const updatedTask = await storage.updateTask(taskId, {
        parent_id: reorderData.parent_id,
        position: reorderData.position
      });
      
      res.json(updatedTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Error reordering task" });
    }
  });

  return httpServer;
}
