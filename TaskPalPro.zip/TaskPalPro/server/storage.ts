import { 
  users, type User, type InsertUser, 
  tasks, type Task, type InsertTask, type UpdateTask 
} from "@shared/schema";
import bcrypt from "bcrypt";
import { db } from "./db";
import { eq, and, isNull, lte, gte, desc, asc, sql, count } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUser(username: string, password: string): Promise<User | null>;
  
  // Task methods
  getAllTasks(userId: number): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: UpdateTask): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  getTaskChildren(taskId: number): Promise<Task[]>;
  getTasksWithNoDueDate(userId: number): Promise<Task[]>;
  getTasksDueOnDate(userId: number, date: string): Promise<Task[]>;
  getTasksDueBetweenDates(userId: number, startDate: string, endDate: string): Promise<Task[]>;
  getUrgentTasks(userId: number, limit?: number): Promise<Task[]>;
  getTaskStats(userId: number): Promise<{
    total: number;
    completed: number;
    dueToday: number;
    overdue: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const now = new Date().toISOString();
    
    const [user] = await db.insert(users).values({
      ...insertUser,
      password: hashedPassword,
      created_at: now
    }).returning();
    
    return user;
  }
  
  async validateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    
    if (!user) {
      return null;
    }
    
    const isPasswordValid = await bcrypt.compare(password, user.password);
    
    if (!isPasswordValid) {
      return null;
    }
    
    return user;
  }

  // Task methods
  async getAllTasks(userId: number): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.user_id, userId));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const now = new Date().toISOString();
    
    const [task] = await db.insert(tasks).values({
      ...insertTask,
      created_at: now,
      updated_at: now
    }).returning();
    
    return task;
  }

  async updateTask(id: number, updateData: UpdateTask): Promise<Task | undefined> {
    const now = new Date().toISOString();
    
    const [updatedTask] = await db.update(tasks)
      .set({
        ...updateData,
        updated_at: now
      })
      .where(eq(tasks.id, id))
      .returning();
    
    return updatedTask || undefined;
  }

  async deleteTask(id: number): Promise<boolean> {
    // First delete all children recursively
    const children = await this.getTaskChildren(id);
    for (const child of children) {
      await this.deleteTask(child.id);
    }
    
    // Then delete the task itself
    const [deletedTask] = await db.delete(tasks)
      .where(eq(tasks.id, id))
      .returning({ id: tasks.id });
    
    return !!deletedTask;
  }
  
  async getTaskChildren(taskId: number): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(eq(tasks.parent_id, taskId));
  }
  
  async getTasksWithNoDueDate(userId: number): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        isNull(tasks.due_date)
      ));
  }
  
  async getTasksDueOnDate(userId: number, date: string): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.due_date, date)
      ));
  }
  
  async getTasksDueBetweenDates(
    userId: number, 
    startDate: string, 
    endDate: string
  ): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        gte(tasks.due_date, startDate),
        lte(tasks.due_date, endDate)
      ));
  }
  
  async getUrgentTasks(userId: number, limit: number = 5): Promise<Task[]> {
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    
    const todayStr = today.toISOString().split('T')[0];
    const tomorrowStr = tomorrow.toISOString().split('T')[0];
    
    // Get tasks that are due today, tomorrow, or overdue
    return await db.select()
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.completed, false),
        lte(tasks.due_date, tomorrowStr)
      ))
      .orderBy(
        desc(tasks.weight),
        asc(tasks.due_date)
      )
      .limit(limit);
  }
  
  async getTaskStats(userId: number): Promise<{
    total: number;
    completed: number;
    dueToday: number;
    overdue: number;
  }> {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    
    // Get total count
    const [totalResult] = await db.select({ count: count() })
      .from(tasks)
      .where(eq(tasks.user_id, userId));
    
    // Get completed count
    const [completedResult] = await db.select({ count: count() })
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.completed, true)
      ));
    
    // Get due today count
    const [dueTodayResult] = await db.select({ count: count() })
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.completed, false),
        eq(tasks.due_date, todayStr)
      ));
    
    // Get overdue count
    const [overdueResult] = await db.select({ count: count() })
      .from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.completed, false),
        lte(tasks.due_date, todayStr)
      ));
    
    return {
      total: Number(totalResult.count || 0),
      completed: Number(completedResult.count || 0),
      dueToday: Number(dueTodayResult.count || 0),
      overdue: Number(overdueResult.count || 0)
    };
  }
}

export const storage = new DatabaseStorage();
