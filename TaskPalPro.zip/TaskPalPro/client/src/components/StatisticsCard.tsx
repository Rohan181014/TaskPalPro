interface StatisticsCardProps {
  taskStats: {
    total: number;
    completed: number;
    dueToday: number;
    overdue: number;
  };
}

export default function StatisticsCard({ taskStats }: StatisticsCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
        <span className="material-icons text-primary mr-2">insights</span>
        Statistics
      </h2>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
          <p className="text-sm text-gray-500 dark:text-gray-400">Total Tasks</p>
          <p className="text-2xl font-semibold text-gray-900 dark:text-white">{taskStats.total}</p>
        </div>
        
        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
          <p className="text-sm text-gray-500 dark:text-gray-400">Completed</p>
          <p className="text-2xl font-semibold text-green-600 dark:text-green-400">{taskStats.completed}</p>
        </div>
        
        <div className="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg">
          <p className="text-sm text-gray-500 dark:text-gray-400">Due Today</p>
          <p className="text-2xl font-semibold text-amber-600 dark:text-amber-400">{taskStats.dueToday}</p>
        </div>
        
        <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-lg">
          <p className="text-sm text-gray-500 dark:text-gray-400">Overdue</p>
          <p className="text-2xl font-semibold text-red-600 dark:text-red-400">{taskStats.overdue}</p>
        </div>
      </div>
    </div>
  );
}
