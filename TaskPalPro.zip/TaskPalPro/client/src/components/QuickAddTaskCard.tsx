import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Task } from "@shared/schema";

const quickAddTaskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  due_date: z.string().optional(),
  weight: z.coerce.number().min(1).max(5).default(3),
  parent_id: z.coerce.number().nullable().default(null),
});

type QuickAddTaskFormValues = z.infer<typeof quickAddTaskSchema>;

interface QuickAddTaskCardProps {
  onSubmit: (taskData: QuickAddTaskFormValues) => void;
  parentOptions: Task[];
}

export default function QuickAddTaskCard({ onSubmit, parentOptions }: QuickAddTaskCardProps) {
  const form = useForm<QuickAddTaskFormValues>({
    resolver: zodResolver(quickAddTaskSchema),
    defaultValues: {
      title: "",
      due_date: new Date().toISOString().split('T')[0],
      weight: 3,
      parent_id: null,
    },
  });
  
  const handleSubmit = (values: QuickAddTaskFormValues) => {
    onSubmit({
      ...values,
      // Convert empty strings to null for optional fields
      due_date: values.due_date || null,
    });
    
    // Reset the form after submission
    form.reset({
      title: "",
      due_date: new Date().toISOString().split('T')[0],
      weight: 3,
      parent_id: null,
    });
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
        <span className="material-icons text-secondary mr-2">add_task</span>
        Quick Add Task
      </h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Title</FormLabel>
                <FormControl>
                  <Input placeholder="Enter task title" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex space-x-4">
            <FormField
              control={form.control}
              name="due_date"
              render={({ field }) => (
                <FormItem className="w-1/2">
                  <FormLabel>Due Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="weight"
              render={({ field }) => (
                <FormItem className="w-1/2">
                  <FormLabel>Priority</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value.toString()}
                    value={field.value.toString()}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">Low</SelectItem>
                      <SelectItem value="2">Medium-Low</SelectItem>
                      <SelectItem value="3">Medium</SelectItem>
                      <SelectItem value="4">Medium-High</SelectItem>
                      <SelectItem value="5">High</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="parent_id"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Parent Task (Optional)</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(value ? parseInt(value) : null)}
                  defaultValue={field.value?.toString() || ""}
                  value={field.value?.toString() || ""}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="None (Root level)" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">None (Root level)</SelectItem>
                    {parentOptions.map((option) => (
                      <SelectItem key={option.id} value={option.id.toString()}>
                        {option.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button type="submit" className="w-full flex items-center justify-center">
            <span className="material-icons mr-1">add</span>
            Add Task
          </Button>
        </form>
      </Form>
    </div>
  );
}
