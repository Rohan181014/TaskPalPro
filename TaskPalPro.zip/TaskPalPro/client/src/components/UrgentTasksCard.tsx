import { format, isToday, isTomorrow, parseISO } from "date-fns";
import { Task } from "@shared/schema";

interface UrgentTasksCardProps {
  urgentTasks: Task[];
  onToggleCompletion: (task: Task) => void;
}

export default function UrgentTasksCard({ urgentTasks, onToggleCompletion }: UrgentTasksCardProps) {
  
  const getTaskBackgroundClass = (task: Task) => {
    if (!task.due_date) return "bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500";
    
    const dueDate = parseISO(task.due_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (isToday(dueDate)) {
      return "bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500";
    } else if (isTomorrow(dueDate)) {
      return "bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500";
    } else if (dueDate < today) {
      return "bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500";
    } else {
      return "bg-amber-50 dark:bg-amber-900/20 border-l-4 border-amber-500";
    }
  };
  
  const formatDueDate = (dueDate: string | null) => {
    if (!dueDate) return "No date";
    
    const date = parseISO(dueDate);
    
    if (isToday(date)) {
      return "Today";
    } else if (isTomorrow(date)) {
      return "Tomorrow";
    } else {
      const now = new Date();
      const diffTime = Math.abs(date.getTime() - now.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 7) {
        return `In ${diffDays} day${diffDays > 1 ? "s" : ""}`;
      } else {
        return format(date, "MMM d, yyyy");
      }
    }
  };
  
  const getDueDateColor = (dueDate: string | null) => {
    if (!dueDate) return "text-gray-400";
    
    const date = parseISO(dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (isToday(date)) {
      return "text-red-500";
    } else if (isTomorrow(date)) {
      return "text-amber-500";
    } else if (date < today) {
      return "text-red-500";
    } else {
      return "text-gray-400";
    }
  };
  
  const getPriorityClass = (weight: number) => {
    switch (weight) {
      case 1:
        return "priority-1";
      case 2:
        return "priority-2";
      case 3:
        return "priority-3";
      case 4:
        return "priority-4";
      case 5:
        return "priority-5";
      default:
        return "priority-3";
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
          <span className="material-icons text-red-500 mr-2">priority_high</span>
          Urgent Tasks
        </h2>
      </div>
      
      {urgentTasks.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <span className="material-icons text-gray-400 text-4xl mb-2">check_circle</span>
          <p>No urgent tasks right now</p>
        </div>
      ) : (
        <div className="space-y-3">
          {urgentTasks.map((task) => (
            <div key={task.id} className={`flex items-center p-3 rounded-md ${getTaskBackgroundClass(task)}`}>
              <div className="flex-grow">
                <div className="flex items-center">
                  <span 
                    className="material-icons text-gray-400 dark:text-gray-500 mr-2 text-sm cursor-pointer"
                    onClick={() => onToggleCompletion(task)}
                  >
                    {task.completed ? "check_circle" : "radio_button_unchecked"}
                  </span>
                  <h3 className={`font-medium text-gray-900 dark:text-white ${task.completed ? 'line-through text-gray-500 dark:text-gray-400' : ''}`}>
                    {task.title}
                  </h3>
                </div>
                <div className="ml-6 text-sm text-gray-500 dark:text-gray-400 flex items-center mt-1">
                  <span className={`material-icons text-xs mr-1 ${getDueDateColor(task.due_date)}`}>event</span>
                  <span>{formatDueDate(task.due_date)}</span>
                </div>
              </div>
              <div className={`priority-indicator ${getPriorityClass(task.weight)} ml-2`}></div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
