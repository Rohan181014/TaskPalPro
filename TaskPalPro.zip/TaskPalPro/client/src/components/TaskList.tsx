import { useState } from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { Task } from "@shared/schema";
import TaskItem from "./TaskItem";
import { restrictToVerticalAxis } from "@dnd-kit/modifiers";

interface TaskWithChildren extends Task {
  children: TaskWithChildren[];
}

interface TaskListProps {
  tasks: TaskWithChildren[];
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: number) => void;
  onToggleCompletion: (task: Task) => void;
  onDragEnd: ({ id, parentId, position }: { id: number, parentId: number | null, position: number }) => void;
  isLoading?: boolean;
}

export default function TaskList({
  tasks,
  onEditTask,
  onDeleteTask,
  onToggleCompletion,
  onDragEnd,
  isLoading = false,
}: TaskListProps) {
  const [expandedTasks, setExpandedTasks] = useState<Set<number>>(new Set());
  
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );
  
  const handleToggleExpand = (taskId: number) => {
    setExpandedTasks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };
  
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      // Extract the taskId and parent taskId from the droppable IDs
      const activeId = Number(active.id.toString().split("-")[0]);
      const overId = Number(over.id.toString().split("-")[0]);
      const overData = over.id.toString().split("-");
      
      let parentId: number | null = null;
      if (overData.length > 1) {
        parentId = Number(overData[1]);
      }
      
      // Find the position based on where it was dropped
      const position = tasks.findIndex(t => t.id === overId);
      
      onDragEnd({
        id: activeId,
        parentId,
        position: position >= 0 ? position : 0
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
        <div className="animate-spin material-icons text-primary text-4xl">refresh</div>
        <p className="mt-4 text-gray-500 dark:text-gray-400">Loading tasks...</p>
      </div>
    );
  }
  
  if (tasks.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
        <span className="material-icons text-gray-400 text-5xl">assignment</span>
        <h3 className="mt-2 text-xl font-medium text-gray-900 dark:text-white">No tasks yet</h3>
        <p className="mt-1 text-gray-500 dark:text-gray-400">Create your first task to get started</p>
      </div>
    );
  }
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Task List Header */}
      <div className="px-6 py-3 border-b border-gray-200 dark:border-gray-700 grid grid-cols-12 gap-4 text-sm font-medium text-gray-500 dark:text-gray-400">
        <div className="col-span-6">Task</div>
        <div className="col-span-2">Due Date</div>
        <div className="col-span-2">Priority</div>
        <div className="col-span-2">Actions</div>
      </div>
      
      {/* Task Items Container - Draggable Area */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
        modifiers={[restrictToVerticalAxis]}
      >
        <SortableContext
          items={tasks.map(task => `${task.id}`)}
          strategy={verticalListSortingStrategy}
        >
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {tasks.map((task) => (
              <TaskItem
                key={task.id}
                task={task}
                level={0}
                expanded={expandedTasks.has(task.id)}
                onToggleExpand={handleToggleExpand}
                onEdit={onEditTask}
                onDelete={onDeleteTask}
                onToggleCompletion={onToggleCompletion}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  );
}
