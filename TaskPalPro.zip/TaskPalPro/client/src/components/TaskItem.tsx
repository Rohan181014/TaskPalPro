import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { format, isToday, isTomorrow, parseISO } from "date-fns";
import { Task } from "@shared/schema";

interface TaskWithChildren extends Task {
  children: TaskWithChildren[];
}

interface TaskItemProps {
  task: TaskWithChildren;
  level: number;
  expanded: boolean;
  onToggleExpand: (taskId: number) => void;
  onEdit: (task: Task) => void;
  onDelete: (taskId: number) => void;
  onToggleCompletion: (task: Task) => void;
}

export default function TaskItem({
  task,
  level,
  expanded,
  onToggleExpand,
  onEdit,
  onDelete,
  onToggleCompletion,
}: TaskItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: `${task.id}${task.parent_id ? `-${task.parent_id}` : ''}` });
  
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };
  
  const hasChildren = task.children && task.children.length > 0;
  
  const formatDueDate = (dueDate: string | null) => {
    if (!dueDate) return "No date";
    
    const date = parseISO(dueDate);
    
    if (isToday(date)) {
      return "Today";
    } else if (isTomorrow(date)) {
      return "Tomorrow";
    } else {
      return format(date, "MMM d, yyyy");
    }
  };
  
  const getDueDateColor = (dueDate: string | null) => {
    if (!dueDate) return "text-gray-400";
    
    const date = parseISO(dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (isToday(date)) {
      return "text-red-500";
    } else if (isTomorrow(date)) {
      return "text-amber-500";
    } else if (date < today) {
      return "text-red-500";
    } else {
      return "text-gray-400";
    }
  };
  
  const getPriorityLabel = (weight: number) => {
    switch (weight) {
      case 1:
        return "Low";
      case 2:
        return "Medium-Low";
      case 3:
        return "Medium";
      case 4:
        return "Medium-High";
      case 5:
        return "High";
      default:
        return "Medium";
    }
  };
  
  const getPriorityClass = (weight: number) => {
    switch (weight) {
      case 1:
        return "priority-1";
      case 2:
        return "priority-2";
      case 3:
        return "priority-3";
      case 4:
        return "priority-4";
      case 5:
        return "priority-5";
      default:
        return "priority-3";
    }
  };
  
  const indentClass = Array(level).fill("task-indent").join(" ");
  
  return (
    <>
      <div
        ref={setNodeRef}
        style={style}
        {...attributes}
        className={`group px-6 py-4 grid grid-cols-12 gap-4 items-center hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors duration-150 ${indentClass} ${task.completed ? 'opacity-70' : ''}`}
      >
        <div className="col-span-6">
          <div className="flex items-center">
            <span 
              className="material-icons text-gray-400 cursor-pointer mr-2 opacity-0 group-hover:opacity-100"
              {...listeners}
            >
              drag_indicator
            </span>
            <span 
              className="material-icons text-gray-400 dark:text-gray-500 mr-2 cursor-pointer" 
              onClick={() => onToggleCompletion(task)}
            >
              {task.completed ? "check_circle" : "radio_button_unchecked"}
            </span>
            <div className={`font-medium text-gray-900 dark:text-white ${task.completed ? 'line-through text-gray-500 dark:text-gray-400' : ''}`}>
              {task.title}
            </div>
            {hasChildren && (
              <button 
                className="ml-2 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300" 
                onClick={() => onToggleExpand(task.id)}
              >
                <span className="material-icons">
                  {expanded ? "expand_more" : "chevron_right"}
                </span>
              </button>
            )}
          </div>
        </div>
        
        <div className="col-span-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
          <span className={`material-icons text-xs mr-1 ${getDueDateColor(task.due_date)}`}>event</span>
          <span>{formatDueDate(task.due_date)}</span>
        </div>
        
        <div className="col-span-2">
          <div className="flex items-center">
            <div className={`priority-indicator ${getPriorityClass(task.weight)} mr-2`}></div>
            <span className="text-sm text-gray-500 dark:text-gray-400">{getPriorityLabel(task.weight)}</span>
          </div>
        </div>
        
        <div className="col-span-2 flex items-center space-x-2">
          <button 
            className="text-gray-400 hover:text-primary dark:hover:text-primary" 
            onClick={() => onEdit(task)}
            title="Edit task"
          >
            <span className="material-icons">edit</span>
          </button>
          <button 
            className="text-gray-400 hover:text-red-500 dark:hover:text-red-500" 
            onClick={() => onDelete(task.id)}
            title="Delete task"
          >
            <span className="material-icons">delete</span>
          </button>
        </div>
      </div>
      
      {expanded && hasChildren && (
        <>
          {task.children.map((childTask) => (
            <TaskItem
              key={childTask.id}
              task={childTask}
              level={level + 1}
              expanded={expanded && hasChildren && childTask.children.length > 0}
              onToggleExpand={onToggleExpand}
              onEdit={onEdit}
              onDelete={onDelete}
              onToggleCompletion={onToggleCompletion}
            />
          ))}
        </>
      )}
    </>
  );
}
