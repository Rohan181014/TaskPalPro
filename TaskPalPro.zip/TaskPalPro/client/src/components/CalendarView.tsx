import React from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import { Task } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

interface CalendarViewProps {
  tasks: Task[];
  onEditTask: (task: Task) => void;
  onToggleCompletion: (task: Task) => void;
  isLoading?: boolean;
}

interface CalendarEvent {
  id: number;
  title: string;
  start: Date;
  end: Date;
  resource: Task;
  backgroundColor?: string;
  borderColor?: string;
  textColor?: string;
}

export default function CalendarView({ tasks, onEditTask, onToggleCompletion, isLoading = false }: CalendarViewProps) {
  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-[600px] w-full" />
      </div>
    );
  }
  
  // Filter tasks with due dates
  const tasksWithDueDates = tasks.filter(task => task.due_date);
  
  // Convert tasks to calendar events
  const events: CalendarEvent[] = tasksWithDueDates.map(task => {
    // Parse due date
    const dueDate = new Date(task.due_date!);
    
    return {
      id: task.id,
      title: task.title,
      start: dueDate,
      end: dueDate,
      resource: task,
      backgroundColor: getEventColor(task),
      borderColor: getEventColor(task),
      textColor: '#ffffff'
    };
  });
  
  // Get color based on task weight and completion status
  const getEventColor = (task: Task) => {
    if (task.completed) {
      return '#64748b'; // Slate for completed tasks
    }
    
    if (!task.weight) return '#3b82f6'; // Default blue
    
    // Color based on priority weight
    if (task.weight >= 8) return '#ef4444'; // Red for high priority
    if (task.weight >= 5) return '#f97316'; // Orange for medium priority
    return '#22c55e'; // Green for low priority
  };
  
  const handleEventClick = (info: any) => {
    const task = info.event.extendedProps.resource as Task;
    onEditTask(task);
  };
  
  return (
    <div className="p-4 bg-white dark:bg-gray-950 rounded-md shadow-sm">
      {tasksWithDueDates.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            No tasks with due dates to display on the calendar
          </p>
        </div>
      ) : (
        <FullCalendar
          plugins={[dayGridPlugin]}
          initialView="dayGridMonth"
          events={events}
          eventClick={handleEventClick}
          headerToolbar={{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,dayGridWeek'
          }}
          height="650px"
          eventTimeFormat={{
            hour: 'numeric',
            minute: '2-digit',
            meridiem: 'short'
          }}
          eventDidMount={(info) => {
            const task = info.event.extendedProps.resource as Task;
            
            // Add tooltip with task description
            if (task.description) {
              info.el.title = task.description;
            }
            
            // Add custom class for completed tasks
            if (task.completed) {
              info.el.classList.add('line-through', 'opacity-60');
            }
          }}
        />
      )}
    </div>
  );
}