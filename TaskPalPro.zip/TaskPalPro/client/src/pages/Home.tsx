import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Task } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { calculatePriorityScore, getUrgentTasks } from "@/lib/priorityUtils";
import CalendarView from "@/components/CalendarView";
import TaskList from "@/components/TaskList";

// Simple schema for task creation/editing
const taskFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  weight: z.number().min(1).max(10).default(5),
  due_date: z.string().optional().nullable(),
  parent_id: z.number().nullable().optional(),
});

type TaskFormValues = z.infer<typeof taskFormSchema>;

export default function Home() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  
  // Check if user is logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch("/api/user", {
          credentials: "include" 
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUsername(userData.username);
        } else {
          // Redirect to login if not authenticated
          setLocation("/login");
        }
      } catch (error) {
        toast({
          title: "Authentication Error",
          description: "Please log in again",
          variant: "destructive"
        });
        setLocation("/login");
      }
    };
    
    checkAuth();
  }, [setLocation, toast]);

  // Form setup
  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "",
      description: "",
      weight: 5,
      due_date: null,
      parent_id: null,
    }
  });
  
  // Fetch all tasks
  const { data: tasks = [], isLoading: isLoadingTasks, refetch } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: !!username, // Only fetch if authenticated
    refetchOnWindowFocus: true,
    refetchInterval: 3000, // Refetch every 3 seconds to ensure we have the latest data
    onSuccess: (data) => {
      // Check for tasks due today or tomorrow and show notifications
      if (Array.isArray(data) && data.length > 0) {
        const today = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(today.getDate() + 1);
        
        const todayStr = today.toISOString().split('T')[0];
        const tomorrowStr = tomorrow.toISOString().split('T')[0];
        
        // Find tasks due today
        const tasksDueToday = data.filter(task => 
          !task.completed && 
          task.due_date === todayStr
        );
        
        // Find tasks due tomorrow
        const tasksDueTomorrow = data.filter(task => 
          !task.completed && 
          task.due_date === tomorrowStr
        );
        
        // Show toast notifications for tasks due today
        if (tasksDueToday.length > 0) {
          toast({
            title: `${tasksDueToday.length} task${tasksDueToday.length > 1 ? 's' : ''} due today!`,
            description: tasksDueToday.length > 1 
              ? `You have ${tasksDueToday.length} tasks that need to be completed today.` 
              : `"${tasksDueToday[0].title}" is due today.`,
            variant: "destructive"
          });
        }
        
        // Show toast notifications for tasks due tomorrow
        if (tasksDueTomorrow.length > 0) {
          toast({
            title: `${tasksDueTomorrow.length} task${tasksDueTomorrow.length > 1 ? 's' : ''} due tomorrow`,
            description: tasksDueTomorrow.length > 1 
              ? `You have ${tasksDueTomorrow.length} tasks due tomorrow.` 
              : `"${tasksDueTomorrow[0].title}" is due tomorrow.`,
            variant: "default"
          });
        }
      }
    }
  });
  
  // Create task mutation
  const createTask = useMutation({
    mutationFn: async (taskData: TaskFormValues) => {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(taskData),
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create task');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Task created successfully:", data);
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      refetch(); // Explicitly refetch tasks after creating a new one
      form.reset();
      toast({
        title: "Success",
        description: "Task created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update task mutation
  const updateTask = useMutation({
    mutationFn: async (task: Task & TaskFormValues) => {
      const response = await fetch(`/api/tasks/${task.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(task),
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update task');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setEditingTask(null);
      form.reset();
      toast({
        title: "Success",
        description: "Task updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete task mutation
  const deleteTask = useMutation({
    mutationFn: async (taskId: number) => {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete task');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Success",
        description: "Task deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Reorder task mutation
  const reorderTask = useMutation({
    mutationFn: async ({ id, parentId, position }: { id: number, parentId: number | null, position: number }) => {
      const response = await fetch(`/api/tasks/${id}/reorder`, {
        method: 'PUT', // Server expects PUT for reordering
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ parent_id: parentId, position }),
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to reorder task');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Success",
        description: "Task reordered successfully",
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error reordering task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Toggle task completion
  const toggleCompletion = useMutation({
    mutationFn: async (task: Task) => {
      const response = await fetch(`/api/tasks/${task.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...task,
          completed: !task.completed
        }),
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update task');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: TaskFormValues) => {
    if (editingTask) {
      // Update existing task
      updateTask.mutate({
        ...editingTask,
        ...data,
      });
    } else {
      // Create new task
      createTask.mutate(data);
    }
  };
  
  // Edit task handler
  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    form.reset({
      title: task.title,
      description: task.description || "",
      weight: task.weight || 5,
      due_date: task.due_date || null,
      parent_id: task.parent_id,
    });
  };
  
  // Cancel edit handler
  const handleCancelEdit = () => {
    setEditingTask(null);
    form.reset();
  };
  
  // Handle delete confirmation
  const handleDeleteTask = (taskId: number) => {
    if (window.confirm("Are you sure you want to delete this task? This action cannot be undone.")) {
      deleteTask.mutate(taskId);
    }
  };

  // Handle logout
  const handleLogout = async () => {
    try {
      const response = await fetch("/api/logout", {
        method: "POST",
        credentials: "include"
      });
      
      if (response.ok) {
        toast({
          title: "Logged out",
          description: "You have been successfully logged out"
        });
        setLocation("/login");
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  // Function to build nested tasks for drag-and-drop functionality
  const buildNestedTasks = (tasks: Task[]) => {
    if (!Array.isArray(tasks)) return [];
    
    // First, create a map of parent tasks
    const parentTasks = tasks.filter(task => task.parent_id === null);
    
    // Create a map of children tasks by parent ID
    const childrenMap: Record<number, Task[]> = {};
    
    tasks.forEach(task => {
      if (task.parent_id !== null) {
        if (!childrenMap[task.parent_id]) {
          childrenMap[task.parent_id] = [];
        }
        childrenMap[task.parent_id].push(task);
      }
    });
    
    // Recursive function to build the nested tree
    const buildTaskTree = (task: Task) => {
      const children = childrenMap[task.id] || [];
      return {
        ...task,
        children: children.map(child => buildTaskTree(child))
      };
    };
    
    // Build the full tree
    return parentTasks.map(task => buildTaskTree(task));
  };
  
  // If tasks is an array, organize them into a hierarchical structure
  const parentTasks = Array.isArray(tasks) 
    ? tasks.filter(task => task.parent_id === null)
    : [];
    
  const childrenMap = Array.isArray(tasks) 
    ? tasks.reduce((acc, task) => {
        if (task.parent_id !== null) {
          if (!acc[task.parent_id]) {
            acc[task.parent_id] = [];
          }
          acc[task.parent_id].push(task);
        }
        return acc;
      }, {} as Record<number, Task[]>)
    : {};
  
  // Render task with its children
  const renderTask = (task: Task, level = 0) => {
    const children = childrenMap[task.id] || [];
    const priorityScore = calculatePriorityScore(task);
    
    // Calculate priority class based on score
    let priorityClass = "bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300";
    if (priorityScore > 70) {
      priorityClass = "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300";
    } else if (priorityScore > 50) {
      priorityClass = "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300";
    } else if (priorityScore > 30) {
      priorityClass = "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300";
    }
    
    return (
      <div key={task.id} className="mb-3">
        <div className={`flex items-center p-3 rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 ${
          level > 0 ? 'ml-6' : ''
        } ${task.parent_id ? 'border-l-4 border-l-blue-300 dark:border-l-blue-600' : ''}`}>
          <Checkbox 
            checked={task.completed || false} 
            onCheckedChange={() => toggleCompletion.mutate(task)} 
            className="mr-3"
          />
          <div className="flex-1">
            <div className="flex items-center">
              <div className={`font-medium mr-2 ${task.completed ? 'line-through text-gray-500 dark:text-gray-400' : ''}`}>
                {task.title}
              </div>
              
              {task.weight && task.weight > 5 && (
                <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300 ml-2">
                  Priority: {task.weight}/10
                </span>
              )}
              
              <span className={`text-xs font-medium ml-auto px-2 py-0.5 rounded ${priorityClass}`}>
                Score: {priorityScore}
              </span>
            </div>
            
            {task.description && (
              <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {task.description}
              </div>
            )}
            
            <div className="flex flex-wrap gap-2 mt-1">
              {task.due_date && (
                <div className="text-xs inline-block px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  Due: {new Date(task.due_date).toLocaleDateString()}
                </div>
              )}
              
              {task.parent_id && (
                <div className="text-xs inline-block px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                  Subtask
                </div>
              )}
              
              {children.length > 0 && (
                <div className="text-xs inline-block px-2 py-0.5 rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  Has {children.length} subtask{children.length > 1 ? 's' : ''}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex space-x-2 ml-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleEditTask(task)}
              className="h-8 w-8 p-0"
              title="Edit task"
            >
              <span className="text-blue-500">✏️</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleDeleteTask(task.id)}
              className="h-8 w-8 p-0"
              title="Delete task"
            >
              <span className="text-red-500">🗑️</span>
            </Button>
          </div>
        </div>
        
        {children.length > 0 && (
          <div className="ml-8 pl-4 border-l-2 border-blue-200 dark:border-blue-800 mt-2">
            {children.map(child => renderTask(child, level + 1))}
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <header className="bg-white shadow dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-blue-600 text-3xl mr-2">📋</span>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">TaskPal</h1>
          </div>
          
          {username && (
            <div className="flex items-center">
              <span className="mr-4 text-gray-600 dark:text-gray-300">
                Welcome, {username}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          )}
        </div>
      </header>
      
      <main className="max-w-5xl mx-auto px-4 py-8">
        {username ? (
          <div className="grid grid-cols-1 gap-6">
            {/* Urgent Tasks Section */}
            {Array.isArray(tasks) && tasks.length > 0 && (
              <Card className="border-l-4 border-l-red-500">
                <CardHeader>
                  <CardTitle className="text-red-600">Urgent Tasks</CardTitle>
                  <CardDescription>High priority tasks that need your attention</CardDescription>
                </CardHeader>
                <CardContent>
                  {getUrgentTasks(tasks, 5).length > 0 ? (
                    <div className="space-y-2">
                      {getUrgentTasks(tasks, 5).map(task => (
                        <div key={task.id} className="flex items-center p-3 bg-red-50 dark:bg-red-900/20 rounded-md">
                          <Checkbox
                            checked={task.completed || false}
                            onCheckedChange={() => toggleCompletion.mutate(task)}
                            className="mr-3"
                          />
                          <div className="flex-1">
                            <div className="font-medium">
                              {task.title}
                            </div>
                            {task.due_date && (
                              <div className="text-xs text-red-600 dark:text-red-400">
                                Due: {new Date(task.due_date).toLocaleDateString()}
                              </div>
                            )}
                          </div>
                          <div className="text-sm font-semibold bg-red-100 dark:bg-red-800 px-2 py-1 rounded text-red-800 dark:text-red-200">
                            Score: {calculatePriorityScore(task)}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 dark:text-gray-400">No urgent tasks at the moment.</p>
                  )}
                </CardContent>
              </Card>
            )}
            
            {/* Tabs for different views */}
            <Tabs defaultValue="list" className="w-full">
              <div className="flex justify-between items-center mb-4">
                <TabsList>
                  <TabsTrigger value="list">List View</TabsTrigger>
                  <TabsTrigger value="calendar">Calendar View</TabsTrigger>
                </TabsList>
                
                <Button 
                  variant="outline" 
                  onClick={() => {
                    handleCancelEdit();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="ml-auto"
                >
                  <span className="mr-1">➕</span> New Task
                </Button>
              </div>
              
              <TabsContent value="list" className="space-y-6">
                {/* Task Form */}
                <Card>
                  <CardHeader>
                    <CardTitle>{editingTask ? "Edit Task" : "Add New Task"}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Title</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter task title" {...field} />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description (optional)</FormLabel>
                              <FormControl>
                                <Textarea placeholder="Enter task description" {...field} />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="due_date"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Due Date (optional)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="date" 
                                    {...field} 
                                    value={field.value || ''} 
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Priority Weight (1-10)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    min={1} 
                                    max={10} 
                                    {...field} 
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || 5)}
                                  />
                                </FormControl>
                                <p className="text-xs text-gray-500">Higher value = higher priority</p>
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {Array.isArray(tasks) && tasks.length > 0 && (
                          <FormField
                            control={form.control}
                            name="parent_id"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Parent Task (optional)</FormLabel>
                                <FormControl>
                                  <select
                                    className="w-full p-2 border rounded-md"
                                    {...field}
                                    value={field.value || ''}
                                    onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                                  >
                                    <option value="">None (Top-level task)</option>
                                    {tasks
                                      .filter(t => !editingTask || t.id !== editingTask.id)
                                      .map((task: Task) => (
                                        <option key={task.id} value={task.id}>
                                          {task.title}
                                        </option>
                                      ))
                                    }
                                  </select>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        )}
                        
                        <div className="flex justify-end space-x-2 pt-2">
                          {editingTask && (
                            <Button type="button" variant="outline" onClick={handleCancelEdit}>
                              Cancel
                            </Button>
                          )}
                          <Button type="submit">
                            {editingTask ? "Update Task" : "Add Task"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
                
                {/* Task List with Drag-and-Drop */}
                <Card>
                  <CardHeader>
                    <CardTitle>My Tasks</CardTitle>
                    <CardDescription>
                      Drag and drop to reorder your tasks
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTasks ? (
                      <div className="flex justify-center py-8">
                        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-500"></div>
                      </div>
                    ) : Array.isArray(tasks) && tasks.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>You don't have any tasks yet. Create one to get started!</p>
                      </div>
                    ) : (
                      <TaskList 
                        tasks={buildNestedTasks(tasks)}
                        onEditTask={handleEditTask}
                        onDeleteTask={handleDeleteTask}
                        onToggleCompletion={(task) => toggleCompletion.mutate(task)}
                        onDragEnd={({ id, parentId, position }) => reorderTask.mutate({ id, parentId, position })}
                        isLoading={isLoadingTasks}
                      />
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="calendar">
                <Card>
                  <CardHeader>
                    <CardTitle>Calendar View</CardTitle>
                    <CardDescription>Visualize your tasks by due date</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <CalendarView 
                      tasks={tasks} 
                      onEditTask={handleEditTask} 
                      onToggleCompletion={task => toggleCompletion.mutate(task)}
                      isLoading={isLoadingTasks}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-500"></div>
          </div>
        )}
      </main>
    </div>
  );
}
