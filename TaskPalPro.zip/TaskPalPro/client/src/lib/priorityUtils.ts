import { Task } from "@shared/schema";
import { isAfter, isBefore, addDays, parseISO } from "date-fns";

// Calculate a priority score for sorting tasks
export function calculatePriorityScore(task: Task): number {
  let score = 0;
  
  // Weight contributes up to 50 points
  score += task.weight * 10;
  
  // Due date contributes up to 50 points
  if (task.due_date) {
    const dueDate = parseISO(task.due_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (isBefore(dueDate, today)) {
      // Overdue tasks get maximum points
      score += 50;
    } else {
      // Tasks due within a week get points based on how soon they're due
      const oneWeekFromNow = addDays(today, 7);
      
      if (isBefore(dueDate, oneWeekFromNow)) {
        // Calculate how many days until due
        const diffTime = Math.abs(dueDate.getTime() - today.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        // Reverse the points (closer = more points)
        score += Math.max(0, 50 - (diffDays * 7));
      }
    }
  }
  
  // Subtract points for completed tasks
  if (task.completed) {
    score -= 75;
  }
  
  return score;
}

// Sort tasks by priority score (highest first)
export function sortTasksByPriority(tasks: Task[]): Task[] {
  return [...tasks].sort((a, b) => calculatePriorityScore(b) - calculatePriorityScore(a));
}

// Get the most urgent tasks
export function getUrgentTasks(tasks: Task[], limit: number = 5): Task[] {
  return sortTasksByPriority(tasks)
    .filter(task => !task.completed) // Only include incomplete tasks
    .slice(0, limit);
}
