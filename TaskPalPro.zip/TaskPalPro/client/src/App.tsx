import { Switch, Route } from "wouter";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";

function App() {
  return (
    <div>App component is not used directly anymore. Routes are defined in main.tsx</div>
  );
}

export default App;
